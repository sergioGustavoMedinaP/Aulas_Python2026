import sqlite3

conn = sqlite3.connect("bd_AlnumMusical.db")
#conn.row_factory = sqlite3.Row
cursor = conn.cursor()

sql = "SELECT * FROM tb_album WHERE artist=?"
cursor.execute(sql, [("Red")])
print( cursor.fetchall())  # ou use fetchone()

print( "\nAqui a lista de todos os registros na tabela:\n")
for row in cursor.execute("SELECT rowid, * FROM tb_album ORDER BY artist"):
   print( row)

print( "\nResultados de uma consulta com LIKE:\n")
sql = """
SELECT * FROM tb_album
WHERE title LIKE 'The%'"""
cursor.execute(sql)
print( cursor.fetchall())
