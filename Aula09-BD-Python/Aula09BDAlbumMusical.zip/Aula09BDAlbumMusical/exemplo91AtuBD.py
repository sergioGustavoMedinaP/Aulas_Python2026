import sqlite3

conn = sqlite3.connect("bd_AlnumMusical.db")
cursor = conn.cursor()

sql = """
UPDATE tb_album
SET artist = 'John Doe'
WHERE artist = 'Andy Hunter'
"""
cursor.execute(sql)
conn.commit()
