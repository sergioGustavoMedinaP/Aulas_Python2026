import sqlite3

conn = sqlite3.connect("bd_AlnumMusical.db")
cursor = conn.cursor()

sql = """
DELETE FROM tb_albuns
WHERE artist = 'John Doe'
"""
cursor.execute(sql)
conn.commit()
