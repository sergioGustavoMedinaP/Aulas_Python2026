import sqlite3

conn = sqlite3.connect("bd_AlnumMusical.db") # cria o BD na memoria  RAM

cursor = conn.cursor()

# insere um registros no BD dados
cursor.execute("INSERT INTO tb_albuns VALUES ('Glow', 'Andy Hunter', '7/24/2012', 'Xplore Records', 'MP3')")

# salva dados no banco
conn.commit()

# insere múltiplos registros de uma só vez usando o método "?", que é mais seguro
albuns = [('Exodus', 'Andy Hunter', '7/9/2002', 'Sparrow Records', 'CD'),
         ('Until We Have Faces', 'Red', '2/1/2011', 'Essential Records', 'CD'),
         ('The End is Where We Begin', 'Thousand Foot Krutch', '4/17/2012', 'TFKmusic', 'CD'),
         ('The Good Life', 'Trip Lee', '4/10/2012', 'Reach Records', 'CD')]

cursor.executemany("INSERT INTO tb_album VALUES (?,?,?,?,?)", albuns)
conn.commit()
