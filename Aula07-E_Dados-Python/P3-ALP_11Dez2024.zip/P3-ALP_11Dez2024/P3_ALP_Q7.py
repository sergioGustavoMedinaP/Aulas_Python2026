ceia_de_natal = {
    "Peru":  150.00,
    "Tender": 120.00,
    "Arroz":  20.00,
    "Farofa":  15.00,
    "Salada de Maionese": 25.00,
    "Panetone":  30.00,
    "Pavê":  40.00,
    "Frutas Secas": 50.00,
    "Uva Passa":  10.00,
    "Vinho":  80.00,
    "Refrigerante":  12.00,
    "Sorvete":  30.00
}

print(ceia_de_natal)

produto_mais_barato = min(ceia_de_natal, key=ceia_de_natal.get)
preco_mais_barato= ceia_de_natal[produto_mais_barato]

produto_mais_caro = max(ceia_de_natal, key=ceia_de_natal.get)
preco_mais_caro= ceia_de_natal[produto_mais_caro]

valor_total = sum(ceia_de_natal.values()) 


# Exibindo os resultados
print(f"O produto mais barato é: {produto_mais_barato} com preço de = R$ {preco_mais_barato:.2f}")
print(f"O produto mais caro é: {produto_mais_caro} com preço de = R$ {preco_mais_caro:.2f}")
print(f"Custo total da ceia de Natal  R$ {valor_total:.2f}")