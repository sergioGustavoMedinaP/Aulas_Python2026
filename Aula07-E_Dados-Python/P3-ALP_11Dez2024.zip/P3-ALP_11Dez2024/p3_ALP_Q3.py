total = 0 
zoologico = {"Leão":12, "macaco":6, "elephant":23, "tigre":7, "urso":20} 

for chave in zoologico.keys(): 
    if len(chave) > 3: 
        print(chave, " tem =", zoologico[chave])
        total = total + zoologico[chave] 

print("Total de animais que tem no zoologico = ", total)

sujeito = "Python" 
verbo = "é" 
predicado= "fantástico"
print(sujeito, verbo, predicado, sep=" ", end="!\n")
print(total) 