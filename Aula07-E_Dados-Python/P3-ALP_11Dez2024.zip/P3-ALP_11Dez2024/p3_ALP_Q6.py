def aluno():
    dic_aluno = {"NOME":"Medina",
                 "RA": 12345,
                 "CURSO": "DSM" }
    
    print("Nome do aluno =", dic_aluno["NOME"])
    print("RA do aluno = ",  dic_aluno["RA"])
    print("Curso = ", dic_aluno["CURSO"])

notas = [7.5, 8.0, 6.5, 9.0, 5.0, 7.0, 8.5, 6.0, 10.0, 9.5, 
        7.8, 6.3, 5.5, 8.2, 7.1, 6.9, 9.8, 7.6, 8.4, 6.7,
        3.4, 6.2, 4.5, 4.2, 8.3, 9.1, 8.8, 7.8, 6.8, 7.8]

nota_min= min(notas)
nota_max = max(notas)
media = sum(notas)/len(notas)

print(f"Notas minima ={nota_min} ")
print(f"Notas maxima ={nota_max} ")
print(f"Media da turma ={media} ")

aluno()
