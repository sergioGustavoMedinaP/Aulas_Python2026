#dicionario = {'1ra_chave':'1ro_valor’, '2a_chave':’2do_valor}
#Chave = Estado
#Valor = Capital 

dicEstadoCapital= {"Rio de Janeiro":"Rio de Janeiro",
                   "São Paulo":"São Paulo",
                   "Minas Gerais": "Belo Horizonte",
                   "Bahia":"Salvador",
                   "Amazonas":"Manaus"}
                       
     
print(" A capital de Rio de Janeiro é ", dicEstadoCapital["Rio de Janeiro"])

for chave in dicEstadoCapital:
    print("Listagem das chaves do dic Estado Capital = ", chave)

print()
for valor in dicEstadoCapital.values():
    print("Listagem dos valores do dicionario Ingles para Espanhol 2 = ", valor) 

print(" Lista de estados: ", list(dicEstadoCapital.keys()))
print()    
print(" Lista de capitais: ", list(dicEstadoCapital.values()))