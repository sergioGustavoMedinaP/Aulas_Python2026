# Lista de notas de 20 alunos
notas = [7.5, 8.0, 6.5, 9.0, 5.0, 7.0, 8.5, 6.0, 10.0, 9.5, 
         7.8, 6.3, 5.5, 8.2, 7.1, 6.9, 9.8, 7.6, 8.4, 6.7]

# Calculando os valores
nota_mais_baixa = min(notas)
nota_mais_alta = max(notas)
media_turma = sum(notas) / len(notas)

# Exibindo os resultados
print("Nota mais baixa  = ", nota_mais_baixa)
print("Nota mais alta =  ", nota_mais_alta)
print("Media da turma = ", media_turma)

print(sorted(notas))