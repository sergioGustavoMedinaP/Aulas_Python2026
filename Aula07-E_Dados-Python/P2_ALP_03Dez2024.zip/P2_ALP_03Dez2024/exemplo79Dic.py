emails_gerentes = {
    "Iguatemi": "iguatemi@gmail.com",
    "Plaza": "plaza@gmail.com",
    "Barra": "barra@gmail.com,"
}

print(emails_gerentes)

email = emails_gerentes['Iguatemi']
print(email)

emails_gerentes['Iguatemi'] = "iguatemi2@gmail.com"
email = emails_gerentes['Iguatemi']
print(email)


email = emails_gerentes.get('Leblon', 'Chave não encontrada')
print(email)

emails_gerentes['Leblon'] = "leblon@gmail.com"
print(emails_gerentes)

emails_gerentes.pop("Leblon")
print(emails_gerentes)

for shopping in emails_gerentes:
    print(shopping)

print(emails_gerentes.keys())

for shopping in emails_gerentes:
    print(emails_gerentes[shopping])

print(emails_gerentes.values())


if "Iguatemi" in emails_gerentes:
    print("Tem sim")
else:
    print("Tem não")

if "iguatemi@gmail.com" in emails_gerentes.values():
    print("O e-mail está presente no dicionário.")