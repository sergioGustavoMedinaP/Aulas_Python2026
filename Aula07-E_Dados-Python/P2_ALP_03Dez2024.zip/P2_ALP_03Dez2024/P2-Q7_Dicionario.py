# Dicionário de compras com produtos e preços
hortifruti = {
    'Mamão': 10.50,
    'Maça': 11.90,
    'Manga': 8.40,
    'Banana': 4.80,
    'Pera': 12.00,
    'Melancia': 4.10,
    'Abacaxi': 7.80,
    'Uva': 11.00,
    'Pessego': 23.50,
    'Ameixa': 25.80
}

# Calculando o valor total e a média
valores = list(hortifruti.values())

print(type (valores))
fruta_mais_barata = min(hortifruti, key=hortifruti.get)
preco_mais_barato= hortifruti[fruta_mais_barata]

fruta_mais_cara = max(hortifruti, key=hortifruti.get)
preco_mais_caro= hortifruti[fruta_mais_cara]


valor_total = sum(hortifruti.values()) 
media_preco = sum(hortifruti.values()) / len(hortifruti)

# Exibindo os resultados
print(f"A fruta mais barata é: {fruta_mais_barata} com preço de = R$ {preco_mais_barato:.2f}")
print(f"A fruta mais cara é: {fruta_mais_cara} com preço de = R$ {preco_mais_caro:.2f}")


print("Média dos preços = R$ ", media_preco)
print("total gasto = R$ ", valor_total)


#for chave in sorted(produtos.keys()):
#    print(chave)

#for item, produto in sorted(enumerate(produtos)):
#    print(item, produto)

for item, produto in sorted(hortifruti.items()):
    print(item,' = R$', produto)