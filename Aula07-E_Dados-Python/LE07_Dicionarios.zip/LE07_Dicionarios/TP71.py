# Criando o dicionário
pessoa = {
    'nome': 'João',
    'idade': 30,
    'cidade': 'São Paulo'
}

# Exibindo o dicionário antes da alteração
print("Antes da alteração:", pessoa)

# Adicionando a chave 'profissão'
pessoa['profissão'] = 'programador'

# Exibindo o dicionário depois da alteração
print("Depois da alteração:", pessoa)

for chave,valor in sorted(pessoa.items()):
    print(chave,":", valor)