# Dicionário de compras com produtos e preços
produtos = {
    'Arroz': 20.50,
    'Feijão': 8.90,
    'Macarrão': 5.40,
    'Óleo': 7.80,
    'Café': 15.00,
    'Açúcar': 4.30,
    'Leite': 6.50,
    'Pão': 12.00,
    'Manteiga': 13.50,
    'Farinha': 9.80
}

# Calculando o valor total e a média
valores = list(produtos.values())

print(type (valores))
mais_barato = min(valores)
mais_caro = max(valores)
valor_total = sum(valores)
media_valores = valor_total / len(produtos)

# Exibindo os resultados

print("Produto mais barato =", mais_barato)
print("Produto mais caro =", mais_caro)
print("Média dos preços = R$ ", media_valores)
print("total gasto = R$ ", valor_total)


#for chave in sorted(produtos.keys()):
#    print(chave)

#for item, produto in sorted(enumerate(produtos)):
#    print(item, produto)

for item, produto in sorted(produtos.items()):
    print(item,' = R$', produto)