# Criando o dicionário
produtos = {
    'nome': 'Camiseta',
    'cor': 'azul',
    'tamanho': 'M',
    'preço': 49.90
}

# Exibindo o dicionário antes da remoção
print("Antes da remoção:", produtos)

# Removendo o item com a chave 'preço'
produtos.pop('preço')

# Exibindo o dicionário depois da remoção
print("Depois da remoção:", sorted(produtos))