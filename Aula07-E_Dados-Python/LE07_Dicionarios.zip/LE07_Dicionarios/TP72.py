# Criando o dicionário
carro = {
    'marca': 'Fiat',
    'modelo': 'Uno',
    'ano': 2015,
    'cor': 'preto'
}

# Acessando e imprimindo os valores
print(f"Marca: {carro['marca']}")
print(f"Modelo: {carro['modelo']}")
print(f"Ano: {carro['ano']}")
print(f"Cor: {carro['cor']}")

for chave, valor in sorted(carro.items()):
    print(chave,': ', valor)