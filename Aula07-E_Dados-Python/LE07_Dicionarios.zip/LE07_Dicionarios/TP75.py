# Lista de palavras
ling_programação = ['python', 'java', 'R','python', 'C', 'R', 'python', 'PHP', 'java', 'R','C++', 'PHP']

# Criando o dicionário para contar as ocorrências
contagem = {}

for palavra in ling_programação:
    if palavra in contagem:
        contagem[palavra] += 1
    else:
        contagem[palavra] = 1

# Exibindo o dicionário com as contagens
print(contagem)