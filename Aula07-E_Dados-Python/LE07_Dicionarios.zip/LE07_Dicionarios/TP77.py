produtos = [20.50, 8.90, 5.40, 7.80, 15.00, 4.30, 6.50, 12.00, 13.50, 9.80]

mais_barato = min(produtos)
mais_caro = max(produtos)
total = sum(produtos)

print("Produto mais barato  = ", mais_barato)
print("Produto mais caro =  ", mais_caro)
print("Total da compra = ", total)

print(sorted(produtos))