#Entrada de Dados
pessoa = {
'nome': 'João',
'idade': 30,
'cidade': 'São Paulo'
}

print("Conteudo do dicionario(Antes) = ",pessoa)
#Processamento
pessoa['Profissão'] = "Programador"

#Saida
print("Conteudo do dicionario (depois)= ",pessoa)
