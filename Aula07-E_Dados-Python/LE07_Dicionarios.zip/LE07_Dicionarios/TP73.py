# Criando o dicionário
aluno = {
    'nome': 'Ana',
    'idade': 22,
    'curso': 'Engenharia'
}

print("Conteudo do dicionario Aluno = ", aluno)

# Verificando se a chave 'nota' existe
if 'nota' in aluno:
    print(f"A nota do aluno é: {aluno['nota']}")
else:
    aluno['nota'] = 7.5
    print("Chave 'nota' adicionada:", aluno)

print(sorted(aluno.items()))