#Entrada de dados
produtos = [20.50, 8.90, 5.40, 7.80, 15.00, 4.30, 6.50, 12.00, 13.50, 9.80]

# processamento
min(produtos)
media = sum(produtos)/len(produtos)

sorted(produtos)

# Saida de dados
print("Produto + barato =  R$ " , min(produtos))
print("Produto + caro = R$ " , max(produtos))
print("Total da compra = R$ " , sum(produtos))
print("Media do valor gasto = R$ " , media)
print(sorted(produtos))